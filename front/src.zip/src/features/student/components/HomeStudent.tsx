export default function HomeStudent() {
    return (
        <h1>HomeStudent</h1>
    )
}