export default function HomeTeacher() {
    return (
        <h1>Teacher</h1>
    )
}